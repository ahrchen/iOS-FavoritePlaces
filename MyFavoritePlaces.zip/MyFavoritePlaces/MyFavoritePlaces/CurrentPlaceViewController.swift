//
//  NowPlayingViewController.swift
//  MusicPlayer
//
//  Created by Max Luttrell on 5/1/18.
//  Copyright © 2018 Max Luttrell. All rights reserved.
//

import UIKit
import AVFoundation



class CurrentPlaceViewController: UIViewController {
    
    

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBAction func addToFavorites(_ sender: Any) {
        
//      make sure place is not already in list
        var alreadyInList = false
        for place in favorites.favorites {
            if(place.place_id == currentPlace?.place_id){
                alreadyInList = true
            }
        }
        if(alreadyInList == false){
            favorites.addFavoritePlace(currentPlace: currentPlace!)
        }
    }
    
    @IBAction func getDirections(_ sender: Any) {
        let latitude = Double((currentPlace?.geometry.location.lat)!)
        let longitude = Double((currentPlace?.geometry.location.lng)!)
        UIApplication.shared.open(URL(string: "https://www.google.com/maps/@\(latitude),\(longitude),16z")!, options: [:], completionHandler: nil)
    }
    
    var currentPlace: PlaceInfo?
    var currentPhoto: PhotoInfo?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = currentPlace?.name
        addressLabel.text = ("Address: \(String(describing: currentPlace!.formatted_address))")
        //reduce decimal place for rating to single decimal
        let x = currentPlace?.rating
        let y = Double(round(10*x!)/10)
        ratingLabel.text = ("Rating: \(String(describing: y))")
        
        //Get photo link and load image
        if currentPlace?.photos != nil {
            self.currentPhoto = currentPlace?.photos![0]
        }
        loadImage()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //helper function to load image
    func loadImage() {
        let imageUrlString =  "https://maps.googleapis.com/maps/api/place/photo?maxwidth=300&key=AIzaSyCgxT5mOL6jRUl9bLXOwvZe7Tz1mvNMFbk&photoreference=\(String(describing: currentPhoto!.photo_reference!))"
        let imageUrl = URL(string: (imageUrlString))!
        let task = URLSession.shared.dataTask(with: imageUrl) {
            data, response, error in

            var displayImage: UIImage?

            if error != nil {
                print("Error in loadImage: \(error!)")
            }

            if let imageData = data {
                displayImage = UIImage(data: imageData)
            }

            DispatchQueue.main.async {
                self.imageView.image = displayImage
            }
        }
        task.resume()
    }

        
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
