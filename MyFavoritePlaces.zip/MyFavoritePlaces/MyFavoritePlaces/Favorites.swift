//
//  Favorites.swift
//  MusicPlayer
//
//  Created by rchen14 on 5/7/18.
//  Copyright © 2018 Max Luttrell. All rights reserved.
//

import Foundation



// model class which holds an array of Tracks
class FavoritePlaces: Codable {
    var favorites = [PlaceInfo]()
    var count: Int { return favorites.count }
    var encodedFavoritePlaces: Data?
    // subscript allows accessing the array using []
    subscript(index: Int) -> PlaceInfo? {
        // this guard statement makes sure that index is in correct range.  if it isn't, the else block is executed to return nil.  otherwise it keeps going to return the correct dwarf for this index
        guard index >= 0 && index < favorites.count else {
            return nil
        }
        
        return favorites[index]
    }
    
    func addFavoritePlace(currentPlace : PlaceInfo) {
        print("num of favorites before \(count)")
        favorites.append(currentPlace)
        print("num of favorites after \(count)")
        encodeFavoritePlaces()
    }
    
    func encodeFavoritePlaces() {
        
        let propertyListEncoder = PropertyListEncoder()
        encodedFavoritePlaces = try? propertyListEncoder.encode(favorites)
        
        if let encodedFavoritePlaces = encodedFavoritePlaces {
            print("we have encoded FavoritePlacess. it is \(encodedFavoritePlaces.count) bytes")
            
            let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            let archiveURL = documentsDirectory[0].appendingPathComponent("favoritePlacesData").appendingPathExtension("plist")
            print("writing to archiveURL: \(archiveURL)")
            do {
                try encodedFavoritePlaces.write(to: archiveURL, options: .noFileProtection)
                print("saved to archiveURL: \(archiveURL)")
            } catch {
                print("error writing file")
            }
        }
    }

    func decodeFavoritePlaces() {
        print("decoding")
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in:  .userDomainMask)
        let archiveURL = documentsDirectory[0].appendingPathComponent("favoritePlacesData").appendingPathExtension("plist")
        print("decoding from archiveURL: \(archiveURL)")
        let propertyListDecoder = PropertyListDecoder()
        if let retrieveData = try? Data(contentsOf: archiveURL),
            let decodedFavoritePlaces = try? propertyListDecoder.decode([PlaceInfo].self, from: retrieveData) {
            print(decodedFavoritePlaces)
            favorites = decodedFavoritePlaces
        }
    }
}

