import Foundation

// make an extension to create a URL with some queries as a parameter
extension URL {
    func withQueries(_ queries: [String: String]) -> URL? {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map { URLQueryItem(name: $0.0, value: $0.1) }
        return components?.url
    }
}


// struct to hold one track of data from iTunes server
struct PlaceInfo: Codable {
    let formatted_address: String
    let name: String
    let place_id: String
    let rating: Double
    let photos : [PhotoInfo]?
    let geometry : GeometryInfo
    
    enum CodingKeys: String, CodingKey {
        case formatted_address
        case name
        case place_id
        case rating
        case photos
        case geometry
    }
    
}

struct GeometryInfo: Codable {
    let location : LocationInfo
    
    enum CodingKeys : String, CodingKey {
        case location
    }
}

struct LocationInfo: Codable {
    let lat : Double
    let lng : Double
    
    enum CodingKeys : String, CodingKey {
        case lat
        case lng
    }
}

struct PhotoInfo: Codable {
    let height : Int?
    let photo_reference : String?
    let width : Int?
    
    enum CodingKeys: String, CodingKey {
        case height
        case photo_reference
        case width
    }
}

struct Results: Codable {
    let results: [PlaceInfo]
    
    enum CodingKeys: String, CodingKey {
        case results
    }
    
}


// Google base URL
let googlePlacesBaseURL = URL(string: "https://maps.googleapis.com/maps/api/place/textsearch/json")!

// createURL creates a URL to query google places server for info for an search term named "name"
func createURL(name: String) -> URL? {
    // iTunes query for an artist with name "name"
    let placesQuery: [String: String] = [
        "query": name,
        "key": "AIzaSyCgxT5mOL6jRUl9bLXOwvZe7Tz1mvNMFbk",
        ]
    return googlePlacesBaseURL.withQueries(placesQuery)
}
