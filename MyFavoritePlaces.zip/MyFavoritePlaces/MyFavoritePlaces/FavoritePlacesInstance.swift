//
//  FavoriteTracksInstance.swift
//  MusicPlayerIII
//
//  Created by Raymond Chen on 5/14/18.
//  Copyright © 2018 Max Luttrell. All rights reserved.
//

import Foundation

//call favorites
let favorites = FavoritePlaces()
